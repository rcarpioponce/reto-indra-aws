"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/interfaces/appointments/handler.ts
var handler_exports = {};
__export(handler_exports, {
  getAppointmentsByInsuredId: () => getAppointmentsByInsuredId
});
module.exports = __toCommonJS(handler_exports);

// src/infrastructure/appointment/appointment-dynamo.repository.ts
var import_aws_sdk = __toESM(require("aws-sdk"));
var AppointmentDynamoRepository = class {
  static {
    __name(this, "AppointmentDynamoRepository");
  }
  constructor() {
    this.client = new import_aws_sdk.default.DynamoDB.DocumentClient();
    this.tableName = process.env.DYNAMODB_TABLE;
  }
  async save(appointment) {
    await this.client.put({
      TableName: this.tableName,
      Item: appointment
    }).promise();
  }
  async updateStatus(appointment) {
    if (!appointment.id) {
      throw new Error("Appointment ID is required for update");
    }
    try {
      console.log(`Updating appointment with id: ${appointment.id}`);
      console.log(`Full appointment data:`, JSON.stringify(appointment));
      await this.client.update({
        TableName: this.tableName,
        Key: {
          id: appointment.id
        },
        UpdateExpression: "set #status = :status, updatedAt = :updatedAt",
        ExpressionAttributeNames: {
          "#status": "status"
        },
        ExpressionAttributeValues: {
          ":status": appointment.status,
          ":updatedAt": (/* @__PURE__ */ new Date()).toISOString()
        },
        ReturnValues: "UPDATED_NEW"
      }).promise();
    } catch (error) {
      console.error("Error updating appointment status:", error);
      throw error;
    }
  }
  async findByInsuredId(insuredId) {
    const result = await this.client.query({
      TableName: this.tableName,
      IndexName: "insuredId-index",
      KeyConditionExpression: "insuredId = :insuredId",
      ExpressionAttributeValues: {
        ":insuredId": insuredId
      }
    }).promise();
    return result.Items ?? [];
  }
};

// src/shared/http/http-response.ts
var respond = /* @__PURE__ */ __name((statusCode, body) => ({
  statusCode,
  body: JSON.stringify(body)
}), "respond");
var ok = /* @__PURE__ */ __name((data) => ({
  statusCode: 200,
  body: JSON.stringify(data)
}), "ok");
var badRequest = /* @__PURE__ */ __name((message, errors) => respond(400, { message, errors }), "badRequest");
var internalError = /* @__PURE__ */ __name((message) => respond(500, { message }), "internalError");

// src/interfaces/appointments/get-appointments.controller.ts
var handleGetAppointmentsByInsuredIdHttp = /* @__PURE__ */ __name(async (event) => {
  try {
    const insuredId = event.pathParameters?.insuredId;
    if (!insuredId) {
      return badRequest("El par\xE1metro insuredId es requerido en la URL");
    }
    const repository = new AppointmentDynamoRepository();
    const appointments = await repository.findByInsuredId(insuredId);
    return ok(appointments);
  } catch (error) {
    console.error("\u274C Error inesperado al consultar citas:", error);
    return internalError("Error interno del servidor");
  }
}, "handleGetAppointmentsByInsuredIdHttp");

// src/interfaces/appointments/handler.ts
var getAppointmentsByInsuredId = /* @__PURE__ */ __name(async (event, context) => {
  return handleGetAppointmentsByInsuredIdHttp(event);
}, "getAppointmentsByInsuredId");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getAppointmentsByInsuredId
});
//# sourceMappingURL=handler.js.map
