"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// swagger/swagger.js
var require_swagger = __commonJS({
  "swagger/swagger.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      "swagger": "2.0",
      "info": {
        "title": "Appointment Service API",
        "version": "1"
      },
      "paths": {
        "/appointments": {
          "post": {
            "summary": "appointment",
            "description": "",
            "operationId": "appointment.post.appointments",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [
              {
                "in": "body",
                "name": "body",
                "description": "Body required in the request",
                "required": true,
                "schema": {
                  "$ref": "#/definitions/AppointmentInput"
                }
              }
            ],
            "responses": {
              "201": {
                "description": "Appointment created successfully"
              },
              "400": {
                "description": "Bad request"
              }
            }
          }
        },
        "/appointments/{insuredId}": {
          "get": {
            "summary": "getAppointmentsByInsuredId",
            "description": "",
            "operationId": "getAppointmentsByInsuredId.get.appointments/{insuredId}",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [
              {
                "name": "insuredId",
                "in": "path",
                "required": true,
                "type": "string"
              }
            ],
            "responses": {
              "200": {
                "description": "Appointments retrieved successfully",
                "schema": {
                  "$ref": "#/definitions/AppointmentsResponse"
                }
              },
              "400": {
                "description": "Bad request"
              }
            }
          }
        }
      },
      "definitions": {
        "AppointmentInput": {
          "properties": {
            "insuredId": {
              "title": "AppointmentInput.insuredId",
              "type": "string"
            },
            "scheduleId": {
              "title": "AppointmentInput.scheduleId",
              "type": "number"
            },
            "countryISO": {
              "enum": [
                "PE",
                "CL"
              ],
              "title": "AppointmentInput.countryISO",
              "type": "string"
            }
          },
          "required": [
            "insuredId",
            "scheduleId",
            "countryISO"
          ],
          "additionalProperties": false,
          "title": "AppointmentInput",
          "type": "object"
        },
        "Appointment": {
          "properties": {
            "id": {
              "title": "Appointment.id",
              "type": "string"
            },
            "insuredId": {
              "title": "Appointment.insuredId",
              "type": "string"
            },
            "scheduleId": {
              "title": "Appointment.scheduleId",
              "type": "number"
            },
            "countryISO": {
              "enum": [
                "PE",
                "CL"
              ],
              "title": "Appointment.countryISO",
              "type": "string"
            },
            "status": {
              "enum": [
                "pending",
                "completed"
              ],
              "title": "Appointment.status",
              "type": "string"
            },
            "createdAt": {
              "title": "Appointment.createdAt",
              "type": "string"
            }
          },
          "required": [
            "id",
            "insuredId",
            "scheduleId",
            "countryISO",
            "status",
            "createdAt"
          ],
          "additionalProperties": false,
          "title": "Appointment",
          "type": "object"
        },
        "AppointmentsResponse": {
          "items": {
            "$ref": "#/definitions/Appointment",
            "title": "AppointmentsResponse.[]"
          },
          "title": "AppointmentsResponse.[]",
          "type": "array"
        }
      },
      "securityDefinitions": {}
    };
  }
});

// swagger/swagger-json.js
var swagger = require_swagger();
exports.handler = async () => {
  return {
    statusCode: 200,
    body: JSON.stringify(swagger)
  };
};
//# sourceMappingURL=swagger-json.js.map
